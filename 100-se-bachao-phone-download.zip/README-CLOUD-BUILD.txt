BUILD APK USING ONLY YOUR ANDROID PHONE (GitHub Actions)

1. Extract 100-se-bachao-source.zip using your phone's Files app.
2. Open https://github.com in Chrome and sign in/create a free account.
3. Create a NEW public or private repository named 100-se-bachao.
4. In the repository choose Add file > Upload files.
5. Upload the CONTENTS of the extracted 100-se-bachao folder, keeping folder paths intact. The .github folder is important. If the mobile browser hides dot-folders, enable show hidden files in your file manager or use GitHub's web editor to create .github/workflows/build-apk.yml from the included workflow file.
6. Commit the uploaded files.
7. Open the repository's Actions tab. Select "Build Android APK" and tap "Run workflow" if it has not started automatically.
8. Wait for the green check mark. Open the completed workflow run, scroll to Artifacts, and download "100-se-bachao-apk".
9. Extract the downloaded artifact ZIP. Install app-debug.apk. Android may ask you to allow Chrome/Files to install unknown apps.

This uses GitHub's hosted build machine; Android Studio and a PC are not required. The APK is a debug-signed APK for personal installation, not a Play Store release.
