100 SE BACHAO! — Android-ready offline score tracker

FEATURES
- Six editable player names and circular gallery photos
- Customizable header image
- Enter one score per player for each round
- Non-negative whole-number scores only
- Running totals and automatic elimination at 100 or above
- Per-player round-by-round history
- Last remaining player wins
- New Game clears scores/history but preserves names and photos/header
- Saves match locally on the device

QUICK TEST / USE
Open index.html in a modern browser. For installable PWA behavior, serve this folder over HTTPS or localhost and use Chrome's Install app / Add to Home screen option. It works offline after first load.

ANDROID APK
This folder also includes an Android Studio WebView wrapper project under android/. Open that folder in Android Studio, allow Gradle sync, then Build > Build Bundle(s) / APK(s) > Build APK(s). The generated debug APK is at app/build/outputs/apk/debug/app-debug.apk.

Note: A compiled APK is not included because this build environment does not have the Android SDK / Gradle Android toolchain installed. The complete app source and Android wrapper are included.
